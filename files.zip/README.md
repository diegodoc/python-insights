# Análise de dados com Python
Projeto em Python de análise de dados para uma plataforma de assinaturas, a fim de diminuir o número de cancelamentos.
